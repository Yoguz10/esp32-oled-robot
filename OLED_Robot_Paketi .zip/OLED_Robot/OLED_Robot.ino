/* ESP32-C3 Super Mini: SDA=4, SCL=5, OLED VCC=3V3.
   Libraries: Adafruit GFX, Adafruit SSD1306, AnimatedGIF by Larry Bank.
   Tools: ESP32C3 Dev Module, USB CDC On Boot Enabled.
   4MB flash partition must include SPIFFS/LittleFS storage (default is OK).
*/
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <AnimatedGIF.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <math.h>

WebServer server(80);
Preferences prefs;
Adafruit_SSD1306 *screen = nullptr;
AnimatedGIF gif;
File gifFile, uploadFile;
int H=32, mode=0;
bool oledOK=false, fsOK=false, gifOpen=false, uploading=false;
String uploadError;
size_t uploadBytes=0;
const size_t MAX_GIF=512*1024;
uint32_t started=0, lastFrame=0, nextGif=0;
int gx=0, gy=0, prevDisposal=0, rx=0, ry=0, rw=0, rh=0;
uint16_t bgColor=0;
uint8_t restoreBuffer[1024];
bool drewFrame=false, gifRestart=false;
const char* modes[]={"normal","happy","surprised","angry","sleepy","wink","love","left","right","heart","wave"};

const char PAGE[] PROGMEM=R"HTML(
<!doctype html><html lang="tr"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mini Robot</title><style>
*{box-sizing:border-box}body{margin:0;background:#101722;color:#edf5ff;font:16px system-ui;max-width:520px;padding:24px;margin:auto}h1{margin-bottom:4px}p{color:#abbdd1;line-height:1.5}.card{background:#1b2737;border:1px solid #324156;padding:18px;border-radius:18px;margin:18px 0}button,select,textarea,input{font:inherit;max-width:100%}button{padding:13px;border:0;border-radius:12px;background:#35c6e8;color:#071923;font-weight:650;cursor:pointer}button.active{background:#a1efad;outline:2px solid white}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}textarea{width:100%;background:#101722;color:white;border:1px solid #53647b;border-radius:10px;padding:12px;margin-bottom:10px}select{padding:8px;border-radius:8px}small{color:#b8c8db}#status{position:sticky;bottom:12px;background:#263c50;padding:12px;border-radius:12px;white-space:pre-wrap}input{margin:8px 0 14px}
</style><h1>Mini Robot</h1><p>Bir ifade seç. Robotun hemen canlansın.</p>
<div class="card"><label>Ekran boyutu <select id="height"><option value="32">128 × 32</option><option value="64">128 × 64</option></select></label> <button onclick="resize()">Uygula</button><p><small>Görüntü eksik veya bozuksa ekranının gerçek boyutunu seç.</small></p></div>
<div class="card"><h2>Hazır ifadeler</h2><div class="grid" id="buttons"></div></div>
<div class="card"><h2>Yazı gönder</h2><textarea id="text" rows="3" maxlength="160" placeholder="Merhaba Oguzhan!"></textarea><button onclick="sendText()">Yazıyı göster</button> <button onclick="clearScreen()">Ekranı temizle</button><p><small>Türkçe harfler sadeleştirilir. Uzun yazılar ekrana sığmayabilir.</small></p></div>
<div class="card"><h2>Kendi GIF'in</h2><p>En fazla 512 KB. GIF boyutu seçtiğin ekran boyutunu aşmamalı. Renkler siyah-beyaza çevrilir. MP4 doğrudan desteklenmez.</p><input type="file" id="file" accept="image/gif,.gif"><button id="upload" onclick="uploadGif()">Yükle ve oynat</button> <button onclick="playSaved()">Kayıtlı GIF'i oynat</button><p><small>Yüklenen GIF elektrik kesilse de saklanır. Açılışta normal gözler gösterilir.</small></p></div>
<div id="status" role="status">Bağlanıyor…</div><script>
const entries=[['normal','Normal / Canlı'],['happy','Mutlu'],['surprised','Şaşkın'],['angry','Kızgın'],['sleepy','Uykulu'],['wink','Göz kırp'],['love','Kalpli gözler'],['left','Sola bak'],['right','Sağa bak'],['heart','Atan kalp'],['wave','Dalga']];
const statusEl=document.getElementById('status');
function say(s){statusEl.textContent=s}
async function post(path,data={}){const r=await fetch(path,{method:'POST',body:new URLSearchParams(data)});const s=await r.text();if(!r.ok)throw Error(s);say(s)}
function active(id){document.querySelectorAll('#buttons button').forEach(b=>b.classList.toggle('active',b.dataset.mode===id))}
for(const [id,label] of entries){const b=document.createElement('button');b.textContent=label;b.dataset.mode=id;b.onclick=async()=>{try{await post('/mode',{name:id});active(id)}catch(e){say(e.message)}};document.getElementById('buttons').append(b)}
async function sendText(){try{await post('/text',{text:document.getElementById('text').value});active('')}catch(e){say(e.message)}}
async function clearScreen(){try{await post('/text',{text:''});active('')}catch(e){say(e.message)}}
async function resize(){try{await post('/height',{height:document.getElementById('height').value});active('normal')}catch(e){say(e.message)}}
async function playSaved(){try{await post('/play');active('')}catch(e){say(e.message)}}
async function uploadGif(){const f=document.getElementById('file').files[0];if(!f)return say('Önce bir GIF seç.');if(f.size>524288)return say('GIF 512 KB sınırını aşıyor.');const b=document.getElementById('upload');b.disabled=true;say('Yükleniyor…');try{const data=new FormData();data.append('file',f);const r=await fetch('/upload',{method:'POST',body:data});const s=await r.text();if(!r.ok)throw Error(s);say(s);active('')}catch(e){say(e.message)}finally{b.disabled=false}}
fetch('/status').then(r=>r.json()).then(s=>{document.getElementById('height').value=s.height;say(s.oled?'Hazır. Bir ifade seç.':'OLED bulunamadı. Bağlantıları kontrol edip RESET tuşuna bas.');active(s.mode)}).catch(()=>say('Bağlantı yok. OLED-TEST ağına bağlan.'));
</script></html>
)HTML";

String plain(String s){
 const char* a[]={"ç","Ç","ğ","Ğ","ı","İ","ö","Ö","ş","Ş","ü","Ü"};
 const char* b[]={"c","C","g","G","i","I","o","O","s","S","u","U"};
 for(int i=0;i<12;i++)s.replace(a[i],b[i]);s.replace("\r","");return s;
}
void stopGif(){if(gifOpen){gif.close();gifOpen=false;}prevDisposal=0;}
bool initOLED(){
 stopGif();oledOK=false;delete screen;screen=new Adafruit_SSD1306(128,H,&Wire,-1);
 uint8_t address=0;for(uint8_t a=0x3C;a<=0x3D;a++){Wire.beginTransmission(a);if(Wire.endTransmission()==0){address=a;break;}}
 if(address)oledOK=screen->begin(SSD1306_SWITCHCAPVCC,address,true,false);
 if(oledOK){screen->clearDisplay();screen->display();}return oledOK;
}
void textScreen(String text){if(!oledOK)return;screen->clearDisplay();screen->setTextSize(1);screen->setTextColor(SSD1306_WHITE);screen->setTextWrap(true);screen->setCursor(0,0);screen->print(plain(text));screen->display();}
uint16_t monochrome(uint16_t c){int r=((c>>11)&31)*255/31,g=((c>>5)&63)*255/63,b=(c&31)*255/31;return (r*299+g*587+b*114>=128000)?SSD1306_WHITE:SSD1306_BLACK;}
void* gifOpenFile(const char* path,int32_t* size){gifFile=LittleFS.open(path,"r");if(!gifFile)return nullptr;*size=gifFile.size();return &gifFile;}
void gifCloseFile(void* h){((File*)h)->close();}
int32_t gifRead(GIFFILE* f,uint8_t* b,int32_t n){File* p=(File*)f->fHandle;int32_t remain=f->iSize-p->position();if(n>remain)n=remain;if(n<=0)return 0;int32_t got=p->read(b,n);f->iPos=p->position();return got;}
int32_t gifSeek(GIFFILE* f,int32_t pos){File* p=(File*)f->fHandle;if(!p->seek(pos))return -1;f->iPos=p->position();return f->iPos;}
void gifDraw(GIFDRAW* d){
 if(!oledOK)return;
 if(!drewFrame){
  if(prevDisposal==2)screen->fillRect(rx,ry,rw,rh,bgColor);
  else if(prevDisposal==3)memcpy(screen->getBuffer(),restoreBuffer,128*H/8);
  if(d->ucDisposalMethod==3)memcpy(restoreBuffer,screen->getBuffer(),128*H/8);
  rx=gx+d->iX;ry=gy+d->iY;rw=d->iWidth;rh=d->iHeight;
  prevDisposal=d->ucDisposalMethod;
  bgColor=d->ucHasTransparency?SSD1306_BLACK:monochrome(d->pPalette[d->ucBackground]);
  drewFrame=true;
 }
 int y=gy+d->iY+d->y;
 for(int x=0;x<d->iWidth;x++){uint8_t index=d->pPixels[x];if(d->ucHasTransparency && index==d->ucTransparent)continue;screen->drawPixel(gx+d->iX+x,y,monochrome(d->pPalette[index]));}
}
String startGif(const char* path){
 stopGif();if(!oledOK)return "OLED bulunamadi.";if(!fsOK)return "Dosya hafizasi acilamadi.";
 if(!gif.open(path,gifOpenFile,gifCloseFile,gifRead,gifSeek,gifDraw))return "GIF acilamadi. Gecerli bir GIF sec.";
 gifOpen=true;
 if(gif.getCanvasWidth()>128 || gif.getCanvasHeight()>H){stopGif();return "GIF fazla buyuk. Ekran boyutuna kucult: 128x"+String(H);}
 gx=(128-gif.getCanvasWidth())/2;gy=(H-gif.getCanvasHeight())/2;
 screen->clearDisplay();drewFrame=false;int ms=100;
 int rc=gif.playFrame(false,&ms);
 if(rc<0 || !drewFrame){stopGif();return "GIF ilk karesi okunamadi.";}
 screen->display();gifRestart=(rc==0);mode=12;nextGif=millis()+max(20,ms);return "";
}
void heart(int cx,int cy,int size){int r=max(2,size/4);screen->fillCircle(cx-r,cy-r,r,1);screen->fillCircle(cx+r,cy-r,r,1);screen->fillTriangle(cx-2*r,cy-r,cx+2*r,cy-r,cx,cy+2*r,1);}
void eyes(uint32_t now){
 screen->clearDisplay();float t=(now-started)/1000.0f;
 int w=28,h=(H==64?30:20),y=H/2-h/2;
 float autoLook=sinf(t*0.8f)*sinf(t*0.31f);int shift=autoLook*8;
 if(mode==7)shift=-14;if(mode==8)shift=14;
 int x1=27+shift,x2=73+shift;
 uint32_t blink=now%4200;int eh=h;
 if(blink<160)eh=max(2,(int)(h*fabsf((int)blink-80)/80));
 if(mode==4)eh=max(3,h/4+(int)(sinf(t*2)*2));
 if(mode==2){w=32;eh=h+4;x1-=2;x2-=2;}
 if(mode==6){int s=(H==64?24:18)+(int)(sinf(t*5)*2);heart(41,H/2,s);heart(87,H/2,s);}
 else if(mode==9)heart(64,H/2,(H==64?44:24)+(int)(sinf(t*7)*3));
 else if(mode==10){for(int x=0;x<128;x++){int yy=H/2+sinf(x*0.10f-t*3)*(H/3);screen->drawPixel(x,yy,1);screen->drawPixel(x,yy+1,1);}}
 else {
  int e1=eh,e2=eh;if(mode==5 && ((now-started)%1800)<650)e2=2;
  screen->fillRoundRect(x1,H/2-e1/2,w,e1,min(6,e1/2),1);
  screen->fillRoundRect(x2,H/2-e2/2,w,e2,min(6,e2/2),1);
  if(mode==1){screen->fillRoundRect(x1-2,H/2+1,w+4,h,8,0);screen->fillRoundRect(x2-2,H/2+1,w+4,h,8,0);}
  if(mode==3){screen->fillTriangle(x1-1,y-2,x1+w+1,y-2,x1+w+1,y+h/2,0);screen->fillTriangle(x2-1,y-2,x2+w+1,y-2,x2-1,y+h/2,0);}
 }
 screen->display();
}
void selectMode(int m){stopGif();mode=m;started=millis();lastFrame=0;}
void reply(int code,String text){server.send(code,"text/plain; charset=utf-8",text);}
void uploadChunk(){
 HTTPUpload &u=server.upload();
 if(u.status==UPLOAD_FILE_START){
  stopGif();mode=11;uploading=true;uploadError="";uploadBytes=0;
  if(!fsOK)uploadError="Dosya hafizasi hazir degil.";
  else {uploadFile=LittleFS.open("/incoming.gif","w");if(!uploadFile)uploadError="Gecici dosya acilamadi.";}
 }else if(u.status==UPLOAD_FILE_WRITE){
  uploadBytes+=u.currentSize;
  if(uploadBytes>MAX_GIF)uploadError="GIF en fazla 512 KB olabilir.";
  if(uploadError.isEmpty() && uploadFile.write(u.buf,u.currentSize)!=u.currentSize)uploadError="Hafiza dolu veya yazma hatasi.";
 }else if(u.status==UPLOAD_FILE_END || u.status==UPLOAD_FILE_ABORTED){
  if(uploadFile)uploadFile.close();uploading=false;
  if(u.status==UPLOAD_FILE_ABORTED){LittleFS.remove("/incoming.gif");uploadError="Yukleme kesildi.";selectMode(0);}
 }
}
void setup(){
 Serial.begin(115200);delay(500);
 prefs.begin("robot",false);H=prefs.getInt("height",32);if(H!=32 && H!=64)H=32;
 WiFi.mode(WIFI_AP);
 // Sifreli ag; bu kartta calisan 8.5 dBm yayin gucu.
 if (!WiFi.softAP("OLED-TEST", "oled12345", 1, false, 4)) {
   Serial.println("Wi-Fi acilamadi");
   return;
 }
 delay(200);
 bool powerSet = WiFi.setTxPower(WIFI_POWER_8_5dBm);
 Serial.print("Yayin gucu 8.5 dBm ayarlandi: ");
 Serial.println(powerSet ? "EVET" : "HAYIR");
 Serial.print("Adres: http://");Serial.println(WiFi.softAPIP());
 Wire.begin(4,5);initOLED();fsOK=LittleFS.begin(true);gif.begin(GIF_PALETTE_RGB565_LE);
 // Restore last valid GIF if power was lost during file replacement.
 if(fsOK){if(!LittleFS.exists("/saved.gif") && LittleFS.exists("/backup.gif"))LittleFS.rename("/backup.gif","/saved.gif");LittleFS.remove("/incoming.gif");}
 server.on("/",HTTP_GET,[]{server.send_P(200,"text/html; charset=utf-8",PAGE);});
 server.on("/status",HTTP_GET,[]{String m=mode<11?modes[mode]:(mode==12?"gif":"text");server.send(200,"application/json",String("{\"height\":")+H+",\"oled\":"+(oledOK?"true":"false")+",\"mode\":\""+m+"\"}");});
 server.on("/mode",HTTP_POST,[]{String n=server.arg("name");for(int i=0;i<11;i++)if(n==modes[i]){selectMode(i);reply(oledOK?200:503,oledOK?"Ifade secildi.":"OLED bulunamadi.");return;}reply(400,"Gecersiz ifade.");});
 server.on("/text",HTTP_POST,[]{String s=server.arg("text");if(s.length()>640){reply(400,"Yazi cok uzun.");return;}selectMode(11);textScreen(s);reply(oledOK?200:503,oledOK?"Yazi gonderildi.":"OLED bulunamadi.");});
 server.on("/height",HTTP_POST,[]{int h=server.arg("height").toInt();if(h!=32 && h!=64){reply(400,"32 veya 64 sec.");return;}H=h;prefs.putInt("height",H);initOLED();selectMode(0);reply(oledOK?200:503,oledOK?"Boyut kaydedildi.":"OLED bulunamadi.");});
 server.on("/play",HTTP_POST,[]{String err=startGif("/saved.gif");reply(err.isEmpty()?200:400,err.isEmpty()?"Kayitli GIF oynatiliyor.":err);});
 server.on("/upload",HTTP_POST,[]{
  if(uploadBytes==0 && uploadError.isEmpty())uploadError="Bos dosya.";
  if(uploadError.isEmpty())uploadError=startGif("/incoming.gif");
  stopGif();
  if(uploadError.isEmpty()){
   LittleFS.remove("/backup.gif");
   if(LittleFS.exists("/saved.gif") && !LittleFS.rename("/saved.gif","/backup.gif"))uploadError="Eski GIF korunamadi.";
   if(uploadError.isEmpty() && !LittleFS.rename("/incoming.gif","/saved.gif")){uploadError="GIF kaydedilemedi.";LittleFS.rename("/backup.gif","/saved.gif");}
   if(uploadError.isEmpty()){LittleFS.remove("/backup.gif");uploadError=startGif("/saved.gif");}
  }
  if(!uploadError.isEmpty()){LittleFS.remove("/incoming.gif");selectMode(0);reply(400,uploadError);}
  else reply(200,"GIF kaydedildi ve oynatiliyor.");
 },uploadChunk);
 server.onNotFound([]{reply(404,"Sayfa bulunamadi.");});server.begin();started=millis();Serial.println(oledOK?"OLED hazir":"OLED bulunamadi");
}
void loop(){
 server.handleClient();uint32_t now=millis();
 if(!uploading && oledOK){
  if(mode<11 && now-lastFrame>=40){lastFrame=now;eyes(now);}
  else if(mode==12 && gifOpen && (int32_t)(now-nextGif)>=0){
   if(gifRestart){gif.reset();prevDisposal=0;screen->clearDisplay();gifRestart=false;}
   drewFrame=false;int ms=100;int rc=gif.playFrame(false,&ms);
   if(rc<0){Serial.println("GIF decode hatasi");selectMode(0);}
   else if(drewFrame){gifRestart=(rc==0);screen->display();nextGif=millis()+max(20,ms);}
   else {gif.reset();prevDisposal=0;screen->clearDisplay();nextGif=millis()+40;}
  }
 }
 delay(1);
}
